package com.meal_prep.MealPrepApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MealPrepAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

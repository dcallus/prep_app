package com.meal_prep.MealPrepApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealPrepAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MealPrepAppApplication.class, args);
	}

}
